-- AlterTable
ALTER TABLE "ride" ADD COLUMN "pickupTime" DATETIME;
