import{k as e,bl as r,aL as t}from"./Izs4x9Bx.js";function a(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{a as u};
