import{k as e,bl as r,aK as t}from"./BwaJMixw.js";function a(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{a as u};
