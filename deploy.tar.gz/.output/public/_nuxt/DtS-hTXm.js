import{k as e,bl as r,aL as t}from"./t6kYrDgT.js";function a(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{a as u};
