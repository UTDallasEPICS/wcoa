import { d as defineEventHandler, p as prisma } from '../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const index = defineEventHandler(async () => {
  return await prisma.volunteer.findMany({
    include: {
      user: true
    },
    orderBy: {
      user: {
        name: "asc"
      }
    }
  });
});

export { index as default };
//# sourceMappingURL=index6.mjs.map
