import { d as defineEventHandler, a as auth, c as createError, p as prisma } from '../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const index = defineEventHandler(async (event) => {
  const session = await auth.api.getSession({
    headers: event.headers
  });
  if (!session) {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized"
    });
  }
  const volunteer = await prisma.volunteer.findUnique({
    where: { userId: session.user.id },
    include: {
      user: true,
      reminders: true
    }
  });
  if (!volunteer) {
    throw createError({
      statusCode: 404,
      statusMessage: "Volunteer profile not found"
    });
  }
  return volunteer;
});

export { index as default };
//# sourceMappingURL=index.mjs.map
