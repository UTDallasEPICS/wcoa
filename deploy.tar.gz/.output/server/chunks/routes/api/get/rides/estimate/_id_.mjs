import { d as defineEventHandler, g as getRouterParam, c as createError, p as prisma, u as useRuntimeConfig } from '../../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const _id_ = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const config = useRuntimeConfig();
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "ID is required"
    });
  }
  const ride = await prisma.ride.findUnique({
    where: { id },
    select: { pickupDisplay: true, dropoffDisplay: true }
  });
  if (!ride) {
    throw createError({
      statusCode: 404,
      statusMessage: "Ride not found"
    });
  }
  const apiKey = config.public.googleMapsApiKey;
  if (!apiKey) {
    return {
      duration: null,
      distance: null,
      durationValue: null,
      distanceValue: null,
      error: "Maps API Key not configured"
    };
  }
  const origin = encodeURIComponent(ride.pickupDisplay);
  const destination = encodeURIComponent(ride.dropoffDisplay);
  try {
    const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${origin}&destination=${destination}&key=${apiKey}`;
    const response = await $fetch(url);
    if (response.status === "OK" && response.routes.length > 0 && response.routes[0].legs.length > 0) {
      const leg = response.routes[0].legs[0];
      return {
        duration: leg.duration.text,
        distance: leg.distance.text,
        durationValue: leg.duration.value,
        // seconds
        distanceValue: leg.distance.value,
        // meters
        error: null
      };
    } else {
      return {
        duration: null,
        distance: null,
        durationValue: null,
        distanceValue: null,
        error: response.status || "No route found"
      };
    }
  } catch (error) {
    console.error("Maps API error:", error);
    return {
      duration: null,
      distance: null,
      durationValue: null,
      distanceValue: null,
      error: "Failed to fetch estimate"
    };
  }
});

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
