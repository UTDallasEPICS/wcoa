import { d as defineEventHandler, g as getRouterParam, c as createError, p as prisma } from '../../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const _email__get = defineEventHandler(async (event) => {
  const email = getRouterParam(event, "email");
  if (!email) {
    throw createError({
      statusCode: 400,
      statusMessage: "Email is required"
    });
  }
  const user = await prisma.user.findUnique({
    where: {
      email
    }
  });
  return user;
});

export { _email__get as default };
//# sourceMappingURL=_email_.get.mjs.map
