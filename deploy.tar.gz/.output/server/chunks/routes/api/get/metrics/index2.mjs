import { d as defineEventHandler, b as getQuery, p as prisma } from '../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const index = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const startDate = query.startDate ? new Date(String(query.startDate)) : void 0;
  const endDate = query.endDate ? new Date(String(query.endDate)) : void 0;
  const dateFilter = startDate || endDate ? {
    scheduledTime: {
      ...startDate && { gte: startDate },
      ...endDate && { lte: endDate }
    }
  } : {};
  const result = await prisma.ride.aggregate({
    _sum: {
      totalRideTime: true
    },
    where: {
      status: "COMPLETED",
      ...dateFilter
    }
  });
  return {
    totalHours: result._sum.totalRideTime || 0
  };
});

export { index as default };
//# sourceMappingURL=index2.mjs.map
