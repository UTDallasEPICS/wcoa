import { d as defineEventHandler, b as getQuery, p as prisma } from '../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const index = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const startDate = query.startDate ? new Date(String(query.startDate)) : void 0;
  const endDate = query.endDate ? new Date(String(query.endDate)) : void 0;
  const dateFilter = startDate || endDate ? {
    scheduledTime: {
      ...startDate && { gte: startDate },
      ...endDate && { lte: endDate }
    }
  } : {};
  const totalRides = await prisma.ride.count({
    where: dateFilter
  });
  if (totalRides === 0) {
    return {
      percentage: 0,
      total: 0,
      completed: 0
    };
  }
  const completedRides = await prisma.ride.count({
    where: {
      status: "COMPLETED",
      ...dateFilter
    }
  });
  return {
    percentage: Math.round(completedRides / totalRides * 100),
    total: totalRides,
    completed: completedRides
  };
});

export { index as default };
//# sourceMappingURL=index.mjs.map
