import { d as defineEventHandler, b as getQuery, p as prisma } from '../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const index = defineEventHandler(async (event) => {
  const query = getQuery(event);
  let startFilter;
  let endFilter;
  if (query.startDate || query.endDate) {
    startFilter = query.startDate ? new Date(String(query.startDate)) : /* @__PURE__ */ new Date(0);
    endFilter = query.endDate ? new Date(String(query.endDate)) : /* @__PURE__ */ new Date(864e13);
  } else {
    const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
    startFilter = new Date(currentYear, 0, 1);
    endFilter = new Date(currentYear + 1, 0, 1);
  }
  const topRidersRaw = await prisma.ride.groupBy({
    by: ["clientId"],
    where: {
      status: "COMPLETED",
      scheduledTime: {
        gte: startFilter,
        lt: endFilter
      }
    },
    _count: {
      id: true
    },
    orderBy: {
      _count: {
        id: "desc"
      }
    },
    take: 5
  });
  const topRiders = await Promise.all(topRidersRaw.map(async (item) => {
    var _a;
    const client = await prisma.client.findUnique({
      where: { id: item.clientId },
      include: { user: true }
    });
    return {
      name: ((_a = client == null ? void 0 : client.user) == null ? void 0 : _a.name) || "Unknown",
      completedRides: item._count.id
    };
  }));
  return topRiders;
});

export { index as default };
//# sourceMappingURL=index3.mjs.map
