import { d as defineEventHandler, b as getQuery, p as prisma } from '../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const index = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const search = query.search;
  const where = search ? {
    OR: [
      { street: { contains: search } },
      { city: { contains: search } },
      { zip: { contains: search } }
    ]
  } : {};
  const addresses = await prisma.address.findMany({
    where,
    take: 20,
    orderBy: {
      street: "asc"
    }
  });
  return addresses.map((a) => ({
    id: a.id,
    label: `${a.street}, ${a.city}, ${a.state} ${a.zip}`,
    address: a
  }));
});

export { index as default };
//# sourceMappingURL=index.mjs.map
