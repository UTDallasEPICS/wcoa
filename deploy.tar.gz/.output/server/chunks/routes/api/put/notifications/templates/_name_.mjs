import { d as defineEventHandler, a as auth, c as createError, r as readBody, p as prisma } from '../../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const _name_ = defineEventHandler(async (event) => {
  var _a;
  const session = await auth.api.getSession({
    headers: event.headers
  });
  if (!session || !session.user || session.user.role !== "ADMIN") {
    throw createError({ statusCode: 403, statusMessage: "Forbidden" });
  }
  const name = (_a = event.context.params) == null ? void 0 : _a.name;
  if (!name) {
    throw createError({ statusCode: 400, statusMessage: "Missing template name" });
  }
  const { subject, body, enabled } = await readBody(event);
  if (subject === void 0 && body === void 0 && enabled === void 0) {
    throw createError({ statusCode: 400, statusMessage: "Nothing to update" });
  }
  const template = await prisma.notificationTemplate.update({
    where: { name },
    data: {
      subject,
      body,
      enabled
    }
  });
  return template;
});

export { _name_ as default };
//# sourceMappingURL=_name_.mjs.map
