import { d as defineEventHandler, g as getRouterParam, r as readBody, c as createError, p as prisma, s as sendNotification, e as sendEmail } from '../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const _id_ = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "ID is required"
    });
  }
  const existingRide = await prisma.ride.findUnique({
    where: { id },
    include: {
      volunteer: {
        include: { user: true }
      },
      client: {
        include: { user: true }
      }
    }
  });
  if (!existingRide) {
    throw createError({
      statusCode: 404,
      statusMessage: "Ride not found"
    });
  }
  const updateData = { ...body };
  if (updateData.scheduledTime) {
    updateData.scheduledTime = new Date(updateData.scheduledTime);
  }
  if (updateData.pickupTime) {
    updateData.pickupTime = new Date(updateData.pickupTime);
  } else if (updateData.pickupTime === null) {
    updateData.pickupTime = null;
  }
  if (body.volunteerId !== void 0) {
    if (body.volunteerId && body.volunteerId.trim() !== "") {
      updateData.volunteerId = body.volunteerId;
    } else {
      updateData.volunteerId = null;
    }
  }
  const ride = await prisma.ride.update({
    where: { id },
    data: updateData,
    include: {
      volunteer: {
        include: { user: true }
      },
      client: {
        include: { user: true }
      }
    }
  });
  const formattedTime = new Date(ride.scheduledTime).toLocaleString();
  const commonContext = {
    client: ride.client.user.name,
    pickup: ride.pickupDisplay,
    dropoff: ride.dropoffDisplay,
    date: formattedTime.split(",")[0],
    time: formattedTime,
    link: `${process.env.APP_URL || "http://localhost:3000"}/rides/${ride.id}`,
    notes: ride.notes || "None"
  };
  if (body.status === "COMPLETED" && existingRide.status !== "COMPLETED") {
    if (ride.volunteer) {
      await sendNotification("RIDE_COMPLETED", ride.volunteer.id, {
        name: ride.volunteer.user.name,
        ...commonContext
      });
    }
    const admins = await prisma.user.findMany({ where: { role: "ADMIN" } });
    const adminEmails = admins.map((admin) => admin.email).filter(Boolean);
    adminEmails.forEach((email) => {
      var _a, _b;
      if (email) {
        sendEmail(
          email,
          "Ride Completed by Volunteer",
          `
            <h1>Ride Completed</h1>
            <p><strong>Volunteer:</strong> ${((_b = (_a = ride.volunteer) == null ? void 0 : _a.user) == null ? void 0 : _b.name) || "N/A"}</p>
            <p><strong>Ride Details:</strong></p>
            <p><strong>From:</strong> ${ride.pickupDisplay}</p>
            <p><strong>To:</strong> ${ride.dropoffDisplay}</p>
            <p><strong>Total Time:</strong> ${ride.totalRideTime || "N/A"} hours</p>
          `
        ).catch(console.error);
      }
    });
  }
  if (body.status === "CANCELLED" && existingRide.status !== "CANCELLED") {
    const volunteerToNotify = existingRide.volunteer;
    if (volunteerToNotify) {
      await sendNotification("RIDE_CANCELLED", volunteerToNotify.id, {
        name: volunteerToNotify.user.name,
        ...commonContext
      });
    }
  }
  return ride;
});

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
