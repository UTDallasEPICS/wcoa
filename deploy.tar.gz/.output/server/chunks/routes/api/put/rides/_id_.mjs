import { d as defineEventHandler, g as getRouterParam, r as readBody, c as createError, p as prisma, s as sendEmail } from '../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const _id_ = defineEventHandler(async (event) => {
  var _a, _b;
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "ID is required"
    });
  }
  const updateData = { ...body };
  if (updateData.scheduledTime) {
    updateData.scheduledTime = new Date(updateData.scheduledTime);
  }
  if (body.volunteerId !== void 0) {
    if (body.volunteerId && body.volunteerId.trim() !== "") {
      updateData.volunteerId = body.volunteerId;
    } else {
      updateData.volunteerId = null;
    }
  }
  const ride = await prisma.ride.update({
    where: { id },
    data: updateData,
    include: {
      volunteer: {
        include: { user: true }
      }
    }
  });
  if (body.status === "COMPLETED") {
    const admins = await prisma.user.findMany({
      where: { role: "ADMIN" }
    });
    const adminEmails = admins.map((admin) => admin.email).filter(Boolean);
    const volunteerEmail = (_b = (_a = ride.volunteer) == null ? void 0 : _a.user) == null ? void 0 : _b.email;
    const notifications = [];
    if (volunteerEmail) {
      notifications.push(sendEmail(
        volunteerEmail,
        "Ride Completion Confirmation",
        `
          <h1>Ride Completed</h1>
          <p>Thank you for completing the ride!</p>
          <p><strong>From:</strong> ${ride.pickupDisplay}</p>
          <p><strong>To:</strong> ${ride.dropoffDisplay}</p>
          <p><strong>Total Time:</strong> ${ride.totalRideTime} hours</p>
        `
      ));
    }
    adminEmails.forEach((email) => {
      var _a2, _b2;
      notifications.push(sendEmail(
        email,
        "Ride Completed by Volunteer",
        `
          <h1>Ride Completed</h1>
          <p><strong>Volunteer:</strong> ${((_b2 = (_a2 = ride.volunteer) == null ? void 0 : _a2.user) == null ? void 0 : _b2.name) || "N/A"}</p>
          <p><strong>Ride Details:</strong></p>
          <p><strong>From:</strong> ${ride.pickupDisplay}</p>
          <p><strong>To:</strong> ${ride.dropoffDisplay}</p>
          <p><strong>Total Time:</strong> ${ride.totalRideTime} hours</p>
        `
      ));
    });
    Promise.allSettled(notifications).catch(console.error);
  }
  return ride;
});

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
