import { d as defineEventHandler, g as getRouterParam, r as readBody, c as createError, p as prisma } from '../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const _id_ = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "ID is required"
    });
  }
  const client = await prisma.client.findUnique({
    where: { id }
  });
  if (!client) {
    throw createError({
      statusCode: 404,
      statusMessage: "Client not found"
    });
  }
  return await prisma.$transaction(async (tx) => {
    if (body.name || body.email !== void 0 || body.phone !== void 0) {
      await tx.user.update({
        where: { id: client.userId },
        data: {
          name: body.name,
          email: body.email || null,
          phone: body.phone
        }
      });
    }
    if (body.street && body.city && body.state && body.zip) {
      const addressData = {
        street: body.street,
        city: body.city,
        state: body.state,
        zip: body.zip
      };
      const address = await tx.address.upsert({
        where: {
          street_city_state_zip: addressData
        },
        update: {},
        create: addressData
      });
      await tx.client.update({
        where: { id },
        data: {
          homeAddressId: address.id
        }
      });
    }
    return await tx.client.findUnique({
      where: { id },
      include: {
        user: true,
        homeAddress: true
      }
    });
  });
});

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
