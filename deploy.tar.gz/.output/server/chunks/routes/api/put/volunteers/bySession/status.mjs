import { d as defineEventHandler, a as auth, c as createError, r as readBody, p as prisma } from '../../../../../nitro/nitro.mjs';
import * as z from 'zod';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const statusSchema = z.object({
  status: z.enum(["AVAILABLE", "UNAVAILABLE"])
});
const status = defineEventHandler(async (event) => {
  const session = await auth.api.getSession({
    headers: event.headers
  });
  if (!session) {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized"
    });
  }
  const body = await readBody(event);
  const validation = statusSchema.safeParse(body);
  if (!validation.success) {
    throw createError({
      statusCode: 400,
      statusMessage: "Invalid status"
    });
  }
  const volunteer = await prisma.volunteer.findUnique({
    where: { userId: session.user.id }
  });
  if (!volunteer) {
    throw createError({
      statusCode: 404,
      statusMessage: "Volunteer profile not found"
    });
  }
  return await prisma.volunteer.update({
    where: { id: volunteer.id },
    data: {
      status: validation.data.status
    }
  });
});

export { status as default };
//# sourceMappingURL=status.mjs.map
