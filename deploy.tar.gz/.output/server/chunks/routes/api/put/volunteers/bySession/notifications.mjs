import { d as defineEventHandler, a as auth, c as createError, r as readBody, p as prisma } from '../../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const notifications = defineEventHandler(async (event) => {
  const session = await auth.api.getSession({
    headers: event.headers
  });
  if (!session || !session.user) {
    throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  }
  const { notifications } = await readBody(event);
  if (!notifications || typeof notifications !== "object") {
    throw createError({ statusCode: 400, statusMessage: "Invalid notifications data" });
  }
  const volunteer = await prisma.volunteer.findUnique({
    where: { userId: session.user.id }
  });
  if (!volunteer) {
    throw createError({ statusCode: 404, statusMessage: "Volunteer profile not found" });
  }
  const currentSettings = volunteer.notificationSettings || {};
  const newSettings = { ...currentSettings, ...notifications };
  await prisma.volunteer.update({
    where: { id: volunteer.id },
    data: { notificationSettings: newSettings }
  });
  return { success: true };
});

export { notifications as default };
//# sourceMappingURL=notifications.mjs.map
