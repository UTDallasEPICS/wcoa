import { d as defineEventHandler, g as getRouterParam, a as auth, c as createError, p as prisma, s as sendNotification, e as sendEmail } from '../../../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const signup = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const session = await auth.api.getSession({
    headers: event.headers
  });
  if (!session) {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized"
    });
  }
  const user = session.user;
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "Ride ID is required"
    });
  }
  const volunteer = await prisma.volunteer.findUnique({
    where: { userId: user.id },
    include: { user: true }
  });
  if (!volunteer) {
    throw createError({
      statusCode: 403,
      statusMessage: "You must be a registered volunteer to sign up."
    });
  }
  if (volunteer.status !== "AVAILABLE") {
    throw createError({
      statusCode: 400,
      statusMessage: "Please set your status to 'AVAILABLE' in settings to sign up for a ride."
    });
  }
  const ride = await prisma.ride.findUnique({
    where: { id },
    include: {
      client: {
        include: {
          user: true
        }
      }
    }
  });
  if (!ride) {
    throw createError({
      statusCode: 404,
      statusMessage: "Ride not found"
    });
  }
  if (ride.status !== "CREATED") {
    throw createError({
      statusCode: 400,
      statusMessage: "Ride is not available for signup"
    });
  }
  const updatedRide = await prisma.ride.update({
    where: { id },
    data: {
      volunteerId: volunteer.id,
      status: "ASSIGNED"
    }
  });
  const admins = await prisma.user.findMany({
    where: { role: "ADMIN" }
  });
  const adminEmails = admins.map((admin) => admin.email).filter(Boolean);
  const volunteerEmail = volunteer.user.email;
  const notifications = [];
  if (volunteerEmail) {
    const formattedTime = new Date(ride.scheduledTime).toLocaleString();
    notifications.push(sendNotification("RIDE_ASSIGNED", volunteer.id, {
      name: volunteer.user.name,
      date: formattedTime.split(",")[0],
      time: formattedTime,
      client: ride.client.user.name,
      pickup: ride.pickupDisplay,
      dropoff: ride.dropoffDisplay,
      link: `${process.env.APP_URL || "http://localhost:3000"}/rides/${id}`
    }));
  }
  adminEmails.forEach((email) => {
    notifications.push(sendEmail(
      email,
      "Volunteer Signed Up for Ride",
      `
        <h1>Volunteer Signed Up</h1>
        <p><strong>Volunteer:</strong> ${volunteer.user.name}</p>
        <p><strong>Ride Details:</strong></p>
        <p><strong>From:</strong> ${ride.pickupDisplay}</p>
        <p><strong>To:</strong> ${ride.dropoffDisplay}</p>
        <p><strong>Time:</strong> ${new Date(ride.scheduledTime).toLocaleString()}</p>
      `
    ));
  });
  Promise.allSettled(notifications).catch(console.error);
  return updatedRide;
});

export { signup as default };
//# sourceMappingURL=signup.mjs.map
