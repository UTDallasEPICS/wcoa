import { d as defineEventHandler, r as readBody, c as createError, p as prisma, s as sendEmail } from '../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const index = defineEventHandler(async (event) => {
  const body = await readBody(event);
  if (!body.clientId || !body.pickup || !body.dropoff || !body.scheduledTime) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing required fields"
    });
  }
  const resolveAddress = async (addr) => {
    return await prisma.address.upsert({
      where: {
        street_city_state_zip: {
          street: addr.street,
          city: addr.city,
          state: addr.state,
          zip: addr.zip
        }
      },
      update: {},
      create: {
        street: addr.street,
        city: addr.city,
        state: addr.state,
        zip: addr.zip
      }
    });
  };
  const pickupAddress = await resolveAddress(body.pickup);
  const dropoffAddress = await resolveAddress(body.dropoff);
  const pickupDisplay = `${body.pickup.street}, ${body.pickup.city}, ${body.pickup.state} ${body.pickup.zip}`;
  const dropoffDisplay = `${body.dropoff.street}, ${body.dropoff.city}, ${body.dropoff.state} ${body.dropoff.zip}`;
  const ride = await prisma.ride.create({
    data: {
      clientId: body.clientId,
      pickupDisplay,
      dropoffDisplay,
      pickupAddressId: pickupAddress.id,
      dropoffAddressId: dropoffAddress.id,
      scheduledTime: new Date(body.scheduledTime),
      notes: body.notes,
      volunteerId: body.volunteerId ? body.volunteerId : void 0,
      status: body.volunteerId ? "ASSIGNED" : "CREATED"
    }
  });
  const volunteers = await prisma.volunteer.findMany({
    include: { user: true },
    where: { status: "AVAILABLE" }
    // Optional: only notify available volunteers
  });
  const emailPromises = volunteers.map((volunteer) => {
    if (volunteer.user.email) {
      const formattedTime = new Date(body.scheduledTime).toLocaleString("en-US", {
        timeZone: "America/Chicago",
        dateStyle: "full",
        timeStyle: "short"
      });
      const dashboardUrl = process.env.BETTER_AUTH_URL || "";
      return sendEmail(
        volunteer.user.email,
        "New Ride Available",
        `
          <h1>New Ride Available</h1>
          <p>A new ride has been posted.</p>
          <p><strong>From:</strong> ${pickupDisplay}</p>
          <p><strong>To:</strong> ${dropoffDisplay}</p>
          <p><strong>Time:</strong> ${formattedTime}</p>
          <p><a href="${dashboardUrl}/rides">Login to the dashboard to sign up.</a></p>
        `
      );
    }
  });
  Promise.allSettled(emailPromises).catch(console.error);
  return ride;
});

export { index as default };
//# sourceMappingURL=index3.mjs.map
