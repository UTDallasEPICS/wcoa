import { d as defineEventHandler, r as readBody, c as createError, p as prisma, f as broadcastNotification } from '../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const index = defineEventHandler(async (event) => {
  const body = await readBody(event);
  if (!body.clientId || !body.pickup || !body.dropoff || !body.scheduledTime) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing required fields"
    });
  }
  const resolveAddress = async (addr) => {
    return await prisma.address.upsert({
      where: {
        street_city_state_zip: {
          street: addr.street,
          city: addr.city,
          state: addr.state,
          zip: addr.zip
        }
      },
      update: {},
      create: {
        street: addr.street,
        city: addr.city,
        state: addr.state,
        zip: addr.zip
      }
    });
  };
  const pickupAddress = await resolveAddress(body.pickup);
  const dropoffAddress = await resolveAddress(body.dropoff);
  const pickupDisplay = `${body.pickup.street}, ${body.pickup.city}, ${body.pickup.state} ${body.pickup.zip}`;
  const dropoffDisplay = `${body.dropoff.street}, ${body.dropoff.city}, ${body.dropoff.state} ${body.dropoff.zip}`;
  const ride = await prisma.ride.create({
    data: {
      clientId: body.clientId,
      pickupDisplay,
      dropoffDisplay,
      pickupAddressId: pickupAddress.id,
      dropoffAddressId: dropoffAddress.id,
      scheduledTime: new Date(body.scheduledTime),
      notes: body.notes,
      volunteerId: body.volunteerId ? body.volunteerId : void 0,
      status: body.volunteerId ? "ASSIGNED" : "CREATED"
    }
  });
  const formattedTime = new Date(body.scheduledTime).toLocaleString("en-US", {
    timeZone: "America/Chicago",
    dateStyle: "full",
    timeStyle: "short"
  });
  await broadcastNotification("RIDE_CREATED", {
    pickup: pickupDisplay,
    dropoff: dropoffDisplay,
    date: formattedTime.split(",")[0],
    // Approximate date
    time: formattedTime,
    link: `${process.env.APP_URL || "http://localhost:3000"}/rides/${ride.id}`
  });
  return ride;
});

export { index as default };
//# sourceMappingURL=index3.mjs.map
