import { d as defineEventHandler, r as readBody, c as createError, p as prisma, e as sendEmail } from '../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const index = defineEventHandler(async (event) => {
  const body = await readBody(event);
  if (!body.name || !body.email) {
    throw createError({
      statusCode: 400,
      statusMessage: "Name and Email are required"
    });
  }
  let user = await prisma.user.findUnique({
    where: { email: body.email }
  });
  if (!user) {
    user = await prisma.user.create({
      data: {
        name: body.name,
        email: body.email,
        phone: body.phone,
        role: "VOLUNTEER"
      }
    });
  } else {
    await prisma.user.update({
      where: { id: user.id },
      data: {
        name: body.name,
        phone: body.phone,
        // Update phone
        role: user.role === "CLIENT" ? "VOLUNTEER" : user.role
        // Upgrade CLIENT to VOLUNTEER
      }
    });
  }
  const existingVolunteer = await prisma.volunteer.findUnique({
    where: { userId: user.id }
  });
  if (existingVolunteer) {
    throw createError({
      statusCode: 400,
      statusMessage: "User is already a volunteer"
    });
  }
  const volunteer = await prisma.volunteer.create({
    data: {
      userId: user.id,
      status: body.status || "AVAILABLE"
    },
    include: {
      user: true
    }
  });
  if (volunteer.user.email) {
    sendEmail(
      volunteer.user.email,
      "Welcome to WCOA Volunteer Program",
      `
        <h1>Welcome, ${volunteer.user.name}!</h1>
        <p>Thank you for signing up as a volunteer.</p>
        <p>You can now log in and browse available rides.</p>
      `
    ).catch(console.error);
  }
  return volunteer;
});

export { index as default };
//# sourceMappingURL=index4.mjs.map
