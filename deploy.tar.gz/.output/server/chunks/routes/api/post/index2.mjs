import { d as defineEventHandler, r as readBody, c as createError, p as prisma } from '../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const index = defineEventHandler(async (event) => {
  const body = await readBody(event);
  if (!body.name || !body.street || !body.city || !body.state || !body.zip) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing required fields"
    });
  }
  let user = null;
  if (body.email) {
    user = await prisma.user.findUnique({
      where: { email: body.email }
    });
  }
  if (!user) {
    user = await prisma.user.create({
      data: {
        name: body.name,
        email: body.email || null,
        phone: body.phone,
        role: "CLIENT"
      }
    });
  } else {
    await prisma.user.update({
      where: { id: user.id },
      data: {
        name: body.name,
        phone: body.phone
        // Don't downgrade ADMIN/VOLUNTEER
      }
    });
  }
  const addressData = {
    street: body.street,
    city: body.city,
    state: body.state,
    zip: body.zip
  };
  const address = await prisma.address.upsert({
    where: {
      street_city_state_zip: addressData
    },
    update: {},
    create: addressData
  });
  const existingClient = await prisma.client.findUnique({
    where: { userId: user.id }
  });
  if (existingClient) {
    throw createError({
      statusCode: 400,
      statusMessage: "User is already a client"
    });
  }
  return await prisma.client.create({
    data: {
      userId: user.id,
      homeAddressId: address.id
    },
    include: {
      user: true,
      homeAddress: true
    }
  });
});

export { index as default };
//# sourceMappingURL=index2.mjs.map
