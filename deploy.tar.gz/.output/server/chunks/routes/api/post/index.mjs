import { d as defineEventHandler, r as readBody, c as createError, p as prisma } from '../../../nitro/nitro.mjs';
import 'better-auth';
import 'better-auth/adapters/prisma';
import 'better-auth/plugins/email-otp';
import 'nodemailer';
import 'better-auth/api';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'cron';
import '@prisma/adapter-better-sqlite3';
import 'node:url';
import '@prisma/client/runtime/client';
import '@iconify/utils';
import 'consola';

const index = defineEventHandler(async (event) => {
  const body = await readBody(event);
  if (!body.name || !body.email) {
    throw createError({
      statusCode: 400,
      statusMessage: "Name and Email are required"
    });
  }
  const existingUser = await prisma.user.findUnique({
    where: { email: body.email }
  });
  if (existingUser) {
    return await prisma.user.update({
      where: { id: existingUser.id },
      data: {
        role: "ADMIN",
        name: body.name,
        phone: body.phone
      }
    });
  } else {
    return await prisma.user.create({
      data: {
        name: body.name,
        email: body.email,
        phone: body.phone,
        role: "ADMIN"
      }
    });
  }
});

export { index as default };
//# sourceMappingURL=index.mjs.map
